import cv2
import numpy as np,sys
from PIL import Image
from matplotlib import pyplot as plt

# This function creates the Gaussian Pyramid. We give it an image as input
def gaussianPyramid(image):
    im = image.copy()
    gaussianPyramid = [image]

    for i in range(0, 6):
        im = cv2.pyrDown(im)
        gaussianPyramid.append(im)

    return gaussianPyramid

# This function creates the Laplacian Pyramid. We give it an image as input
def laplacianPyramid(gaussianPy):

    laplacianPyramid = [gaussianPy[5]]

    for i in range(5, 0, -1):
        pyrUp = cv2.pyrUp(gaussianPy[i])
        substract = cv2.subtract(gaussianPy[i-1],pyrUp)
        laplacianPyramid.append(substract)

    return laplacianPyramid

# This function builds the images,
def buildImage(laplacian1, laplacian2):

    # We start to build the final image that will be displayed
    halves = []

    for left, right in zip(laplacian1, laplacian2):
        # We get the shape of the image, we only need the columns so the other
        # don't really matter
        row, column, other = left.shape
        # We stack the arrays in a way that forms the final image
        # I found this to give me a very hard time
        juntos = np.hstack(( left[:, 0:int(column/2)], right[:, int(column/2):] ))
        halves.append(juntos)

    # Now we create the final image, this is the final result
    image = halves[0]

    for i in range(1,6):
        image = cv2.pyrUp(image)
        image = cv2.add(image, halves[i])

    return image

"""

===  Main program  ===

Over here we will demostrate the program by first mixing the apple and the Orange
(as in the examples), and the we will mix my brother and me

"""

# We read the two files
apple = cv2.imread('data/apple.jpg')
orange = cv2.imread('data/orange.jpg')

# We create the Gaussian Pyramids
gaussianApple = gaussianPyramid(apple)
gaussianOrange = gaussianPyramid(orange)

# We create the Laplacian Pyramids
laplacianApple = laplacianPyramid(gaussianApple)
laplacianOrange = laplacianPyramid(gaussianOrange)

# We add all up together and display it
AppleOrange = buildImage(laplacianApple, laplacianOrange)

plt.imshow(cv2.cvtColor(AppleOrange, cv2.COLOR_BGR2RGB))
plt.title("Apple + Orange")
plt.axis('off')
plt.show()


# Now we test it with my brother and me


# We read the two files
edu = cv2.imread('data/edu.jpg')
carlos = cv2.imread('data/carlos.jpg')

# We create the Gaussian Pyramids
gaussianEdu = gaussianPyramid(edu)
gaussianCarlos = gaussianPyramid(carlos)

# We create the Laplacian Pyramids
laplacianEdu = laplacianPyramid(gaussianEdu)
laplacianCarlos = laplacianPyramid(gaussianCarlos)

# We add all up together and display it
EduardoCarlos = buildImage(laplacianEdu, laplacianCarlos)

plt.imshow(cv2.cvtColor(EduardoCarlos, cv2.COLOR_BGR2RGB))
plt.title("Eduardo + Carlos")
plt.axis('off')
plt.show()
